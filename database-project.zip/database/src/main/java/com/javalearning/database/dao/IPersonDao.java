package com.javalearning.database.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.javalearning.database.bean.Person;
import com.javalearning.database.exceptions.ApplicationException;

public interface IPersonDao {
	public List<Person> getPersonDetails () throws ApplicationException;
	public void insertPerson() throws ApplicationException;
	public void deletePerson() throws ApplicationException;
	public void updatePerson() throws ApplicationException;
	public void handleTransaction() throws ApplicationException;
	public void insertPersonTransaction(Connection con) throws SQLException;
	public void updatePersonTransaction(Connection con) throws SQLException;
}
