package com.javalearning.database.service;

import java.util.List;

import com.javalearning.database.bean.Person;
import com.javalearning.database.dao.IPersonDao;
import com.javalearning.database.dao.PersonDaoImpl;
import com.javalearning.database.exceptions.ApplicationException;

public class PersonServiceImpl implements IPersonService {

	@Override
	public List<Person> getAllPersonDetails() throws ApplicationException {
		IPersonDao dao = new PersonDaoImpl();
		List<Person> persons;
		try {
			persons = dao.getPersonDetails();
		} catch (ApplicationException e) {
			throw new ApplicationException(e);
		}
		return persons;
	}

	@Override
	public void insertPerson() throws ApplicationException {
		IPersonDao dao = new PersonDaoImpl();
		dao.insertPerson();
		
	}

	@Override
	public void updatePerson() throws ApplicationException {
		IPersonDao dao = new PersonDaoImpl();
		dao.updatePerson();
		
	}

	@Override
	public void deletePerson() throws ApplicationException {
		IPersonDao dao = new PersonDaoImpl();
		dao.deletePerson();
		
	}

	@Override
	public void handleTransaction() throws ApplicationException {
		IPersonDao dao = new PersonDaoImpl();
		dao.handleTransaction();
		
	}

}
