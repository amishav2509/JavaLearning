package com.javalearning.database.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


public class ConnectionUtility {
	
	private static final Log logger = LogFactory.getLog(ConnectionUtility.class);
	
	public static Connection CreateDBConnection() {
		Connection con = null;
		try {
			
			ResourceBundle bundle = ResourceBundle.getBundle("application");
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(bundle.getString("mysql.url"), bundle.getString("mysql.username"), bundle.getString("mysql.password"));
			
		} catch (ClassNotFoundException e) {
			logger.error(e);
		} catch (SQLException e) {
			logger.error(e);
		}
		return con;
	}
}
