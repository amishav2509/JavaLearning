package com.javalearning.database.main;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.javalearning.database.bean.Person;
import com.javalearning.database.exceptions.ApplicationException;
import com.javalearning.database.service.IPersonService;
import com.javalearning.database.service.PersonServiceImpl;

public class MainClass {
	
	private static final Log logger = LogFactory.getLog(MainClass.class);

	public static void main(String[] args) {
		IPersonService service = new PersonServiceImpl();
		
		List<Person> list; 
		try {
			//service.insertPerson();
			//service.updatePerson();
			//service.deletePerson();
			service.handleTransaction();
			list = service.getAllPersonDetails();
			for(Person person : list) {
				System.out.println("Inside main");
				System.out.println(person);
			}
			
			
		} catch (ApplicationException e) {
			logger.error(e);
		}
		
	}

}
