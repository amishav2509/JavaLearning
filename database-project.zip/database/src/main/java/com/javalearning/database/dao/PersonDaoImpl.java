package com.javalearning.database.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.javalearning.database.bean.Person;
import com.javalearning.database.exceptions.ApplicationException;
import com.javalearning.database.utility.ConnectionUtility;

public class PersonDaoImpl implements IPersonDao {

	private static final Log logger = LogFactory.getLog(PersonDaoImpl.class);
	
	@Override
	public List<Person> getPersonDetails() throws ApplicationException {
		
		List<Person> personList = null;
		Connection con = null;
		try {
			con = ConnectionUtility.CreateDBConnection();
			PreparedStatement pstmt = con.prepareStatement("SELECT * FROM person");
			ResultSet rs = pstmt.executeQuery();
			personList = new ArrayList<Person>();
			
			while (rs.next()) {
				Person person = new Person();
				Integer id = rs.getInt(1);
				String firstName = rs.getString(2);
				String lastName = rs.getString(3);
				String address = rs.getString(4);
				String city = rs.getString(5);
				person.setId(id);
				person.setFirstName(firstName);
				person.setLastName(lastName);
				person.setAddress(address);
				person.setCity(city);
				personList.add(person);
				}
		} catch (SQLException e) {
			throw new ApplicationException(e);
		}finally {
			if (null != con)
				try {
					con.close();
				} catch (SQLException e) {
					logger.error(e);
				} 
		}
		return personList;
	}

	@Override
	public void insertPerson() throws ApplicationException {
		Connection con = null;
		PreparedStatement pstmt;
		try {
			con = ConnectionUtility.CreateDBConnection();
			pstmt = con.prepareStatement("INSERT INTO person(first_name, last_name,address,city) VALUES(?,?,?,?)");
			pstmt.setString(1, "Anshu");
			pstmt.setString(2, "Verma");
			pstmt.setString(3, "Talwade");
			pstmt.setString(4, "Pune");
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new ApplicationException(e);
		}finally {
			if (null != con)
				try {
					con.close();
				} catch (SQLException e) {
					logger.error(e);
				}
		}
		
	}

	@Override
	public void deletePerson() throws ApplicationException {
		Connection con= null;
		PreparedStatement pstmt;
		try {
			con = ConnectionUtility.CreateDBConnection();
			pstmt = con.prepareStatement("DELETE FROM PERSON WHERE FIRST_NAME=?");
			pstmt.setString(1, "Anshu");
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new ApplicationException(e);
		}finally {
			if (null != con)
				try {
					con.close();
				} catch (SQLException e) {
					logger.error(e);
				}
		}
		
	}

	@Override
	public void updatePerson() throws ApplicationException {
		Connection con= null;
		PreparedStatement pstmt;
		
		try {
			con = ConnectionUtility.CreateDBConnection();
			pstmt = con.prepareStatement("UPDATE PERSON SET CITY=? WHERE FIRST_NAME=?");
			pstmt.setString(1, "Kolkata");
			pstmt.setString(2, "Anshu");
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new ApplicationException(e);
		}finally {
			if (null!=con)
				try {
					con.close();
				} catch (SQLException e) {
					logger.error(e);;
				}
		}
		
		
	}

	@Override
	public void handleTransaction() throws ApplicationException {
		Connection con = null;
		
		try {
			con = ConnectionUtility.CreateDBConnection();
			con.setAutoCommit(false);	//Auto commit is set to false
			insertPersonTransaction(con);	//setting connection boundary 
			updatePersonTransaction(con);
			con.commit();//manually committing the changes on db 
		} catch (SQLException e) {
			if (null != con)
				try {
					con.rollback();//rollback the changes if any of insert/delete operation failed
				} catch (SQLException e1) {
					throw new ApplicationException(e1);
				}
			throw new ApplicationException(e);
			
		}finally {
			if(null != con)
				try {
					con.close();
				} catch (SQLException e) {
					logger.equals(e);
				}
		}
		
		
	}

	@Override
	public void insertPersonTransaction(Connection con) throws SQLException {
		try {
			PreparedStatement pstmt = con.prepareStatement("INSERT INTO person(first_name, last_name,address,city) VALUES(?,?,?,?)");
			pstmt.setString(1, "Anjali");
			pstmt.setString(2, "Verma");
			pstmt.setString(3, "Delhi");
			pstmt.setString(4, "Delhi");
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new SQLException(e);
		}
		
		
	}

	@Override
	public void updatePersonTransaction(Connection con) throws SQLException {
		PreparedStatement pstmt;
		try {
			pstmt = con.prepareStatement("UPDATE PERSON SET ADDRESS=? WHERE FIRST_NAME=?");
			pstmt.setString(1, "CP");
			pstmt.setString(2, "Anjali");
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new SQLException(e);
		}
		
		
	}
}
	
