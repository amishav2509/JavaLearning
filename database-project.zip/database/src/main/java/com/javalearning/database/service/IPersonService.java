package com.javalearning.database.service;

import java.util.List;

import com.javalearning.database.bean.Person;
import com.javalearning.database.exceptions.ApplicationException;

public interface IPersonService {

	public List<Person> getAllPersonDetails() throws ApplicationException;
	public void insertPerson() throws ApplicationException;
	public void updatePerson() throws ApplicationException;
	public void deletePerson() throws ApplicationException;
	public void handleTransaction() throws ApplicationException;
}
